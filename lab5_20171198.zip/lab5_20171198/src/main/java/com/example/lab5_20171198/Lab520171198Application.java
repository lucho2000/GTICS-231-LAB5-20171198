package com.example.lab5_20171198;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lab520171198Application {

	public static void main(String[] args) {
		SpringApplication.run(Lab520171198Application.class, args);
	}

}

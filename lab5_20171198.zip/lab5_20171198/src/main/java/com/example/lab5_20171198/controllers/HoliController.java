package com.example.lab5_20171198.controllers;


import org.springframework.stereotype.Controller;

@Controller

public class HoliController {
}

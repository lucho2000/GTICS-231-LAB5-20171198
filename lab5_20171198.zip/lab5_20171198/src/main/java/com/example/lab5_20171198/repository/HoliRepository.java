package com.example.lab5_20171198.repository;

import org.springframework.data.jpa.repository.JpaRepository;

public interface HoliRepository extends JpaRepository<User,Integer> {
}

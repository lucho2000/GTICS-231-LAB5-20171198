package com.example.lab5_20171198;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lab520171198ApplicationTests {

	@Test
	void contextLoads() {
	}

}
